import streamlit as st
import numpy as np
from PIL import Image
from tensorflow.keras.models import load_model
import os

# --- CONFIGURARE PAGINĂ ---
st.set_page_config(
    page_title="SIA Reciclare - Etapa 6",
    page_icon="♻️",
    layout="wide"
)

# --- CĂI ȘI CLASE ---
MODEL_PATH = 'models/model_final.keras'
# Ordinea este critică (alfabetică, exact ca la antrenare)
CLASSES = ['glass', 'metal', 'paper', 'plastic']

# --- FUNCȚIE PENTRU LOGICA CELOR 4 COȘURI ---
def get_bin_info(label):
    """Returnează culoarea, iconița și mesajul în funcție de material."""
    if label == 'paper':
        return {
            "bin_name": "COȘUL ALBASTRU (Hârtie/Carton)",
            "color": "blue",
            "icon": "🟦",
            "msg": "Hârtia trebuie să fie curată și uscată. Fără șervețele murdare!"
        }
    elif label == 'plastic':
        return {
            "bin_name": "COȘUL GALBEN (Plastic)",
            "color": "gold", # Streamlit warning e galben
            "icon": "🟨",
            "msg": "Turtiți PET-urile! Spălați recipientele cu resturi alimentare."
        }
    elif label == 'glass':
        return {
            "bin_name": "COȘUL VERDE (Sticlă)",
            "color": "green",
            "icon": "🟩",
            "msg": "Fără capace (capacele merg la metal/plastic). Sticla se spală."
        }
    elif label == 'metal':
        return {
            "bin_name": "COȘUL ROȘU / GRI (Metal)",
            "color": "red", # Streamlit error e roșu
            "icon": "🟥",
            "msg": "Doze de aluminiu, conserve. Vă rugăm să le clătiți."
        }
    return None

# --- ÎNCĂRCARE MODEL (CACHED) ---
@st.cache_resource
def load_app_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return load_model(MODEL_PATH)

# --- INTERFAȚA PRINCIPALĂ ---
st.title("♻️ Sistem Inteligent de Sortare Deșeuri")
st.markdown("**Etapa 6:** Optimizare Model & Integrare Finală")

# Bara laterală pentru selecție mod
st.sidebar.title("Meniu")
app_mode = st.sidebar.selectbox("Alege metoda de intrare:", 
                                ["📸 Camera Live", "📂 Încărcare Fișier"])

# Încărcare model
model = load_app_model()

if model is None:
    st.error(f"⚠️ EROARE: Nu găsesc modelul la '{MODEL_PATH}'.")
    st.stop()

# Variabilă pentru a stoca imaginea (indiferent de sursă)
input_image = None

# --- LOGICA DE INTRARE (CAMERA vs UPLOAD) ---
if app_mode == "📸 Camera Live":
    camera_file = st.camera_input("Fă o poză obiectului")
    if camera_file is not None:
        input_image = Image.open(camera_file)

elif app_mode == "📂 Încărcare Fișier":
    uploaded_file = st.file_uploader("Alege o imagine...", type=["jpg", "png", "jpeg"])
    if uploaded_file is not None:
        input_image = Image.open(uploaded_file)

# --- PROCESARE ȘI AFIȘARE ---
if input_image is not None:
    # Creăm două coloane: Stânga (Imagine), Dreapta (Rezultat)
    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("Imaginea analizată")
        st.image(input_image, use_container_width=True)

    with col2:
        st.subheader("Rezultatul Analizei")
        
        # 1. Preprocesare (Resize la 224x224 + Normalizare)
        img_resized = input_image.resize((224, 224))
        img_array = np.array(img_resized) / 255.0
        img_array = np.expand_dims(img_array, axis=0)

        # 2. Predicție
        predictions = model.predict(img_array)
        score = predictions[0]
        max_conf = np.max(score)
        label_idx = np.argmax(score)
        label_name = CLASSES[label_idx]

        # 3. Obținere info coș
        bin_info = get_bin_info(label_name)

        # 4. Afișare colorată în funcție de coș
        result_str = f"{bin_info['icon']} Detectat: **{label_name.upper()}**"
        
        # Folosim casete colorate specifice Streamlit
        if bin_info['color'] == 'blue':
            st.info(result_str)      # Albastru
            st.info(f"🚮 {bin_info['bin_name']}")
        elif bin_info['color'] == 'green':
            st.success(result_str)   # Verde
            st.success(f"🚮 {bin_info['bin_name']}")
        elif bin_info['color'] == 'gold':
            st.warning(result_str)   # Galben
            st.warning(f"🚮 {bin_info['bin_name']}")
        else:
            st.error(result_str)     # Roșu (Metal)
            st.error(f"🚮 {bin_info['bin_name']}")

        # Mesaj educativ
        st.caption(f"💡 Info: {bin_info['msg']}")

        # 5. Bara de Confidence (Cerință Etapa 6)
        st.markdown("---")
        st.write("📊 **Nivel de încredere (Confidence):**")
        st.progress(int(max_conf * 100))
        st.write(f"Modelul este **{max_conf*100:.2f}%** sigur.")

        # Debug (Opțional, bun pentru prezentare)
        with st.expander("Vezi probabilitățile detaliate"):
            for i, class_name in enumerate(CLASSES):
                st.write(f"{class_name.capitalize()}: {score[i]*100:.2f}%")