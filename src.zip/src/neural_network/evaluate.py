import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix

# --- CONFIGURARE ---
# Aflăm căile automat
script_location = os.path.dirname(os.path.abspath(__file__))
# MODIFICARE AICI: Am adăugat încă un dirname pentru a ieși din 'src'
project_root = os.path.dirname(os.path.dirname(script_location))

test_dir = os.path.join(project_root, "data", "test")
model_path = os.path.join(project_root, "models", "model_final.keras")
save_img_dir = os.path.join(project_root, "docs", "images")

# Parametri (trebuie să fie la fel ca la antrenare)
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

def evaluate_model():
    # 1. Verificăm dacă există modelul
    if not os.path.exists(model_path):
        print("EROARE: Nu găsesc 'model_final.keras'. Rulează întâi 'train_model.py'!")
        return

    print(f"Se încarcă modelul din: {model_path}")
    model = load_model(model_path)

    # 2. Pregătim datele de TEST
    # IMPORTANT: shuffle=False este obligatoriu pentru matricea de confuzie corectă!
    if not os.path.exists(test_dir):
        print(f"EROARE: Nu găsesc folderul de test la: {test_dir}")
        print("Rulează din nou 'prepare_data.py' dacă lipsește.")
        return

    test_datagen = ImageDataGenerator(rescale=1./255)
    
    print(f"Căutăm imagini în: {test_dir}")
    test_generator = test_datagen.flow_from_directory(
        test_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        shuffle=False 
    )

    # Verificăm dacă a găsit imagini
    if test_generator.samples == 0:
        print("Nu am găsit nicio imagine în folderul de test! Verifică prepare_data.py.")
        return

    # 3. Evaluare Generală (Loss și Acuratețe)
    print("\nCalculăm scorul general...")
    results = model.evaluate(test_generator)
    print(f"\nREZULTAT FINAL PE TEST:")
    print(f"Loss (Eroare): {results[0]:.4f}")
    print(f"Acuratețe: {results[1]*100:.2f}%")

    # 4. Generăm Predicțiile pentru Matricea de Confuzie
    print("\nGenerăm matricea de confuzie...")
    Y_pred = model.predict(test_generator)
    y_pred = np.argmax(Y_pred, axis=1) # Clasa prezisă de AI
    y_true = test_generator.classes    # Clasa reală (din folder)

    # Luăm numele claselor (Glass, Paper, etc.)
    class_labels = list(test_generator.class_indices.keys())

    # 5. Raport Detaliat (Text)
    print("\n--- Raport Detaliat ---")
    print(classification_report(y_true, y_pred, target_names=class_labels))

    # 6. Desenăm Matricea de Confuzie (Grafic)
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_labels, yticklabels=class_labels)
    plt.ylabel('Clasa Reală (Ce era de fapt)')
    plt.xlabel('Clasa Prezisă (Ce a zis AI-ul)')
    plt.title('Matricea de Confuzie')
    
    # Salvăm graficul
    if not os.path.exists(save_img_dir):
        os.makedirs(save_img_dir)
        
    save_path = os.path.join(save_img_dir, "confusion_matrix.png")
    plt.savefig(save_path)
    print(f"\nGraficul a fost salvat în: {save_path}")
    print("Poți închide graficul pentru a termina scriptul.")
    plt.show()

if __name__ == "__main__":
    evaluate_model()