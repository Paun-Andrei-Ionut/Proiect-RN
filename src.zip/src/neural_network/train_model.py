import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, Input
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping

# --- 1. CONFIGURARE ---
# Căile către date (presupunem că ai split-uit datele în train/validation)
base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
train_dir = os.path.join(base_dir, 'data', 'train')
val_dir = os.path.join(base_dir, 'data', 'validation')

# Parametri
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 20 # Creștem numărul de epoci

# --- 2. GENERATOARE DE DATE (AICI E SECRETUL!) ---
# Pentru Train aplicăm Augmentare (rotiri, zoom, etc.)
train_datagen = ImageDataGenerator(
    rescale=1./255,             # Normalizare
    rotation_range=40,          # Rotește imaginea cu până la 40 grade
    width_shift_range=0.2,      # Mută stânga-dreapta
    height_shift_range=0.2,     # Mută sus-jos
    shear_range=0.2,            # Deformare
    zoom_range=0.2,             # Zoom in/out
    horizontal_flip=True,       # Oglindire
    fill_mode='nearest'         # Cum umple golurile după rotire
)

# Pentru Validare NU aplicăm augmentare (vrem să vedem realitatea)
val_datagen = ImageDataGenerator(rescale=1./255)

print(f"[INFO] Caut date în: {train_dir}")

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

# --- 3. CONSTRUIRE MODEL (CNN ÎMBUNĂTĂȚIT) ---
model = Sequential([
    Input(shape=(224, 224, 3)),
    
    # Bloc 1
    Conv2D(32, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    # Bloc 2
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    # Bloc 3
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    # Bloc 4 (Nou) - Ca să prindă detalii fine
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    Flatten(),
    Dropout(0.5), # Uită 50% din neuroni random ca să nu tocească
    
    Dense(512, activation='relu'),
    Dense(4, activation='softmax') # 4 Clase: glass, metal, paper, plastic
])

model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

# --- 4. ANTRENARE ---
print("[INFO] Începe antrenarea...")

# Early Stopping: Se oprește singur dacă nu mai învață timp de 5 epoci
early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

history = model.fit(
    train_generator,
    epochs=EPOCHS,
    validation_data=validation_generator,
    callbacks=[early_stop]
)

# --- 5. SALVARE ---
save_path = os.path.join(base_dir, 'models', 'model_final.keras')
model.save(save_path)
print(f"[SUCCES] Model salvat la: {save_path}")